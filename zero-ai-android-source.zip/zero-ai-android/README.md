# ZERO AI Android

Native Android WebView shell with a bundled, responsive bilingual UI, local chat history, and configurable backend URL.

- Min SDK: API 24 (Android 7.0)
- The repository is source code, not a prebuilt APK.
- Real AI features require a separately hosted backend exposing `POST /api/chat` and `POST /api/image`. Keep API keys server-side.
- A GitHub Actions workflow builds a debug APK and uploads it as an artifact.

See `README.fa.md` for Persian instructions.
